'use strict';

var utils = require('../utils/writer.js');
var Public = require('../service/PublicService');

module.exports.getAllRooms = function getAllRooms (req, res, next) {
  Public.getAllRooms()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getMessages = function getMessages (req, res, next, roomId) {
  Public.getMessages(roomId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
