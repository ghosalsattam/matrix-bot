'use strict';


/**
 * Fetch Available channels for the given matrix server.
 * Fetch Available channels for the given matrix server. 
 *
 * returns List
 **/
exports.getAllRooms = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ { }, { } ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Fetch Available channels for the given matrix server.
 * Fetch Available channels for the given matrix server. 
 *
 * roomId String 
 * returns List
 **/
exports.getMessages = function(roomId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ { }, { } ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

